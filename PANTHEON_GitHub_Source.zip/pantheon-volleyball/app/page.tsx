"use client";

import Image from "next/image";
import { useMemo, useState } from "react";

type Player = {
  number: number;
  name: string;
  shortName: string;
  role: string;
  group: string;
  height: number;
  photo: string;
  captain?: boolean;
  viceCaptain?: boolean;
};

type Match = {
  opponent: string;
  score: string;
  competition: "Лига" | "Кубок";
  stage: string;
  result: "win" | "loss";
};

const players: Player[] = [
  { number: 10, name: "Мартинович Николай Николаевич", shortName: "Николай Мартинович", role: "Доигровщик / центральный", group: "Доигровщики", height: 182, photo: "/players/martinovich.jpg", captain: true },
  { number: 13, name: "Сечкин Виталий Алексеевич", shortName: "Виталий Сечкин", role: "Доигровщик", group: "Доигровщики", height: 189, photo: "/players/sechkin.jpg", viceCaptain: true },
  { number: 9, name: "Садиков Павел Александрович", shortName: "Павел Садиков", role: "Либеро", group: "Либеро", height: 176, photo: "/players/sadikov.jpg" },
  { number: 11, name: "Узор Дмитрий Александрович", shortName: "Дмитрий Узор", role: "Доигровщик", group: "Доигровщики", height: 182, photo: "/players/uzor.jpg" },
  { number: 69, name: "Гуральник Роман Игоревич", shortName: "Роман Гуральник", role: "Доигровщик", group: "Доигровщики", height: 173, photo: "/players/guralnik.jpg" },
  { number: 5, name: "Брагин Владислав Владимирович", shortName: "Владислав Брагин", role: "Доигровщик", group: "Доигровщики", height: 174, photo: "/players/bragin.jpg" },
  { number: 12, name: "Ложенко Павел Андреевич", shortName: "Павел Ложенко", role: "Центральный блокирующий", group: "Центральные", height: 190, photo: "/players/lozhenko.jpg" },
  { number: 17, name: "Лукоянов Владислав Александрович", shortName: "Владислав Лукоянов", role: "Центральный блокирующий", group: "Центральные", height: 180, photo: "/players/lukoianov.jpg" },
  { number: 92, name: "Коптин Дмитрий Сергеевич", shortName: "Дмитрий Коптин", role: "Диагональный", group: "Диагональные", height: 190, photo: "/players/koptin.jpg" },
  { number: 7, name: "Михайлов Илья Андреевич", shortName: "Илья Михайлов", role: "Связующий", group: "Связующие", height: 180, photo: "/players/mikhailov.jpg" },
];

const matches: Match[] = [
  { opponent: "Армагедец", score: "3 : 2", competition: "Кубок", stage: "Финал", result: "win" },
  { opponent: "Ладога", score: "3 : 0", competition: "Кубок", stage: "1/2 финала", result: "win" },
  { opponent: "Виллози", score: "3 : 1", competition: "Кубок", stage: "1/4 финала", result: "win" },
  { opponent: "Next Gen", score: "3 : 0", competition: "Кубок", stage: "3 тур", result: "win" },
  { opponent: "Длань", score: "3 : 0", competition: "Кубок", stage: "2 тур", result: "win" },
  { opponent: "SkyNet", score: "3 : 0", competition: "Кубок", stage: "1 тур", result: "win" },
  { opponent: "VOLLEYART 3", score: "2 : 3", competition: "Лига", stage: "2 круг", result: "loss" },
  { opponent: "ANTIFIRE", score: "3 : 1", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "Дом молодёжи Атлант", score: "3 : 0", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "На easy", score: "2 : 3", competition: "Лига", stage: "2 круг", result: "loss" },
  { opponent: "Valencia Spike", score: "3 : 0", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "Дикари", score: "3 : 2", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "VolleySert", score: "0 : 3", competition: "Лига", stage: "2 круг", result: "loss" },
  { opponent: "Next Gen", score: "3 : 0", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "Газпром ЦПС", score: "3 : 2", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "Надежда М", score: "3 : 1", competition: "Лига", stage: "2 круг", result: "win" },
  { opponent: "ЛУЧ", score: "3 : 0", competition: "Лига", stage: "2 круг", result: "win" },
];

const roleFilters = ["Все", "Доигровщики", "Центральные", "Связующие", "Диагональные", "Либеро"];

export default function Home() {
  const [roleFilter, setRoleFilter] = useState("Все");
  const [resultFilter, setResultFilter] = useState<"all" | "win" | "loss">("all");
  const [showAllResults, setShowAllResults] = useState(false);

  const visiblePlayers = useMemo(
    () => roleFilter === "Все" ? players : players.filter((player) => player.group === roleFilter),
    [roleFilter],
  );

  const filteredMatches = matches.filter((match) => resultFilter === "all" || match.result === resultFilter);
  const visibleMatches = showAllResults ? filteredMatches : filteredMatches.slice(0, 6);

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="PANTHEON — на главную">
          <span className="brand-mark">P</span>
          <span>PANTHEON</span>
        </a>
        <nav aria-label="Основная навигация">
          <a href="#calendar">Матчи</a>
          <a href="#results">Результаты</a>
          <a href="#team">Команда</a>
          <a href="#life">Life</a>
          <a href="#coach">Тренер</a>
        </nav>
        <a className="header-cta" href="#calendar">Сезон 26/27</a>
      </header>

      <section className="hero" id="top">
        <Image className="hero-image" src="/photos/pantheon-team-portrait.jpg" alt="Волейбольная команда PANTHEON в игровой форме" fill priority unoptimized sizes="100vw" />
        <div className="hero-shade" />
        <div className="hero-content">
          <div className="eyebrow"><span /> Санкт-Петербург · 6×6</div>
          <h1>PANTHEON</h1>
          <p className="hero-slogan">Стоим друг за друга.<br />Играем за победу.</p>
          <div className="hero-actions">
            <a className="button button-gold" href="#calendar">Ближайшие игры <span>↗</span></a>
            <a className="button button-ghost" href="#team">Смотреть состав</a>
          </div>
        </div>
        <div className="hero-stats" aria-label="Итоги сезона 2025/26">
          <div><strong>01</strong><span>Кубок Лайт А</span></div>
          <div><strong>02</strong><span>Лайт-Север 1</span></div>
          <div><strong>14</strong><span>Побед во 2 круге и кубке</span></div>
        </div>
      </section>

      <section className="calendar section" id="calendar">
        <div className="section-heading">
          <div><p className="kicker">Новый сезон</p><h2>Следующий матч</h2></div>
          <span className="season-pill">2026 / 27</span>
        </div>
        <div className="next-match-card">
          <div className="next-copy">
            <p className="next-label">Расписание формируется</p>
            <h3>Новый соперник.<br />Та же цель.</h3>
            <p>Календарь сезона появится здесь сразу после публикации КВЛ‑СПб.</p>
          </div>
          <div className="matchup" aria-label="Будущий матч PANTHEON">
            <div className="team-emblem">P</div>
            <div className="versus"><span>VS</span><small>дата уточняется</small></div>
            <div className="unknown-emblem">?</div>
          </div>
          <a className="text-link" href="https://v-open.spb.ru/blizhajshie-igry.html" target="_blank" rel="noreferrer">Календарь КВЛ‑СПб <span>↗</span></a>
        </div>
      </section>

      <section className="season-story" id="victory">
        <Image src="/photos/pantheon-team-lineup.jpg" alt="Команда PANTHEON перед матчем" fill unoptimized sizes="100vw" />
        <div className="story-overlay" />
        <div className="story-content">
          <p className="kicker">Сезон 2025 / 26</p>
          <h2>Кубок наш.<br />Пьедестал наш.</h2>
          <p>Первое место в Кубке Лайт А и второе место в Лайт‑Север 1. Сезон, в котором команда подтвердила характер результатом.</p>
        </div>
        <figure className="cup-photo">
          <Image src="/photos/cup/vlad-cup.jpg" alt="Влад с кубком после победы PANTHEON" fill unoptimized sizes="(max-width: 700px) 72vw, 31vw" />
          <figcaption><strong>01</strong><span>Кубок Лайт А<br />Санкт‑Петербург</span></figcaption>
        </figure>
      </section>

      <section className="results section" id="results">
        <div className="section-heading results-heading">
          <div><p className="kicker">Архив сезона</p><h2>Результаты</h2></div>
          <div className="filters" role="group" aria-label="Фильтр результатов">
            <button className={resultFilter === "all" ? "active" : ""} onClick={() => setResultFilter("all")}>Все</button>
            <button className={resultFilter === "win" ? "active" : ""} onClick={() => setResultFilter("win")}>Победы</button>
            <button className={resultFilter === "loss" ? "active" : ""} onClick={() => setResultFilter("loss")}>Поражения</button>
          </div>
        </div>
        <div className="season-summary" aria-label="Итоги второго круга Лайт-Север 1">
          <div><span>Место</span><strong>2</strong></div><div><span>Игры</span><strong>11</strong></div><div><span>Победы</span><strong>8</strong></div><div><span>Очки</span><strong>24</strong></div>
        </div>
        <div className="match-list">
          {visibleMatches.map((match, index) => (
            <article className="match-row" key={`${match.competition}-${match.opponent}-${index}`}>
              <div className={`result-badge ${match.result}`}>{match.result === "win" ? "П" : "ПР"}</div>
              <div className="competition"><strong>{match.competition}</strong><span>{match.stage}</span></div>
              <div className="teams"><span>PANTHEON</span><span>{match.opponent}</span></div>
              <strong className="score">{match.score}</strong>
            </article>
          ))}
        </div>
        {filteredMatches.length > 6 && (
          <button className="show-more" onClick={() => setShowAllResults((value) => !value)}>{showAllResults ? "Свернуть результаты" : `Показать все матчи (${filteredMatches.length})`} <span>{showAllResults ? "↑" : "↓"}</span></button>
        )}
      </section>

      <section className="team section" id="team">
        <div className="section-heading team-heading">
          <div><p className="kicker">Игроки PANTHEON</p><h2>Состав команды</h2></div>
          <p>Десять разных характеров.<br />Одна система на площадке.</p>
        </div>
        <div className="filters role-filters" role="group" aria-label="Фильтр игроков по амплуа">
          {roleFilters.map((role) => <button key={role} className={roleFilter === role ? "active" : ""} onClick={() => setRoleFilter(role)}>{role}</button>)}
        </div>
        <div className="player-grid">
          {visiblePlayers.map((player) => (
            <article className="player-card" key={player.number}>
              <div className="player-photo">
                <Image src={player.photo} alt={player.name} fill unoptimized sizes="(max-width: 720px) 50vw, 20vw" />
                <span className="player-number">{String(player.number).padStart(2, "0")}</span>
                {(player.captain || player.viceCaptain) && <span className="captain-badge">{player.captain ? "Капитан" : "Вице-капитан"}</span>}
              </div>
              <div className="player-info"><h3>{player.shortName}</h3><p>{player.role}</p><span>{player.height} см</span></div>
            </article>
          ))}
        </div>
      </section>

      <section className="life section" id="life">
        <div className="section-heading life-heading">
          <div><p className="kicker">PANTHEON вне площадки</p><h2>TEAM LIFE</h2></div>
          <p>Мы встречаемся не только у сетки.<br />Команда — это всё, что происходит между играми.</p>
        </div>
        <div className="life-gallery">
          <figure className="life-wide">
            <Image src="/photos/life/life-pavilion.jpg" alt="Команда PANTHEON на совместной встрече" fill unoptimized sizes="(max-width: 700px) 100vw, 62vw" />
            <figcaption><span>01</span> Вместе вне зала</figcaption>
          </figure>
          <figure className="life-tall">
            <Image src="/photos/life/life-court.jpg" alt="Игроки PANTHEON после матча" fill unoptimized sizes="(max-width: 700px) 100vw, 34vw" />
            <figcaption><span>02</span> С чего всё начиналось</figcaption>
          </figure>
          <figure className="life-bottom">
            <Image src="/photos/life/life-park.jpg" alt="Команда PANTHEON в парке" fill unoptimized sizes="(max-width: 700px) 100vw, 62vw" />
            <figcaption><span>03</span> Один ритм</figcaption>
          </figure>
        </div>
      </section>

      <section className="coach section" id="coach">
        <div className="coach-card">
          <div className="coach-gallery">
            <div className="coach-photo coach-main"><Image src="/photos/coach/maria-portrait.jpg" alt="Тренер PANTHEON Мария Петрова" fill unoptimized sizes="(max-width: 800px) 70vw, 34vw" /></div>
            <div className="coach-photo coach-small"><Image src="/players/petrova.jpg" alt="Мария Петрова" fill unoptimized sizes="(max-width: 800px) 30vw, 15vw" /></div>
            <div className="coach-photo coach-small"><Image src="/photos/coach/maria-selfie.jpg" alt="Мария Петрова" fill unoptimized sizes="(max-width: 800px) 30vw, 15vw" /></div>
          </div>
          <div className="coach-copy">
            <p className="kicker">Тренер команды</p><h2>Петрова<br />Мария</h2>
            <blockquote>Командная работа, дисциплина и готовность сделать ещё один шаг — за себя и за партнёра.</blockquote>
            <div className="coach-meta"><div><span>Роль</span><strong>Главный тренер</strong></div><div><span>Игровое амплуа</span><strong>Связующий</strong></div><div><span>Рост</span><strong>180 см</strong></div></div>
          </div>
        </div>
      </section>

      <footer>
        <div className="footer-brand"><span className="brand-mark">P</span><strong>PANTHEON</strong><p>Любительская волейбольная команда<br />Санкт-Петербург</p></div>
        <div className="footer-links"><a href="#calendar">Матчи</a><a href="#results">Результаты</a><a href="#team">Команда</a><a href="#life">Life</a><a href="#coach">Тренер</a></div>
        <div className="footer-note"><p>Данные состава и результатов: <a href="https://v-open.spb.ru/" target="_blank" rel="noreferrer">КВЛ‑СПб ↗</a></p><p>© 2026 PANTHEON</p></div>
      </footer>
    </main>
  );
}
